#ifndef HEADER_H
#define HEADER_H

#include <iostream>
#include <string>
#include <windows.h>

using namespace std;

	string userName;

	void programIntro() {
		cout << "This program will remind you every 15 minutes to get up out of your chair, the choice is yours." << endl;
		cout << "Enter your name, human: ";
		cin >> userName;
	}


	int timeBotTest() {
		for (int i = 3; i >= 0; --i)
		{
			cout << i;
			Beep(800, 900);
			Sleep(1000);
			system("cls");
			cout << "If your volume is turned up, I'm sorry" << endl;
		}
		return 0;
	}

	int timeBot() {
		for (int i = 900; i >= 0; --i)
		{
			cout << i;
			Beep(800, 900);
			Sleep(1000);
			system("cls");
			cout << "If your volume is turned up, I'm sorry" << endl;
		}
		return 0;
	}

#endif
