//Anna Edwards
//Time bot

#include <iostream>
#include "Header.h"
#include <time.h>

using namespace std;

int main() {

	//calling intro function
	programIntro();
	//calling the test function
	timeBotTest();
	//15 minute Timer
	//timeBot();

	system("PAUSE");
	return 0;
}